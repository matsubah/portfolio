import { chromium } from 'playwright';
import fs from 'fs';
import { PNG } from 'pngjs';
import pixelmatch from 'pixelmatch';

const pages = [
  { name: 'about', path: '/about' },
  { name: 'skodate', path: '/skodate' },
  { name: 'book', path: '/book' },
  { name: 'top', path: '/' },
  { name: 'chumon', path: '/chumon' },
  { name: 'ckodate', path: '/ckodate' },
  { name: 'cmansion', path: '/cmansion' },
  { name: 'reform_renovation', path: '/reform_renovation' },
  { name: 'online', path: '/online' },
  { name: 'reserve', path: '/reserve' },
  { name: 'thanks', path: '/thanks' },
  { name: 'voices_online', path: '/voices-online' },
  { name: 'voices_shop', path: '/voices-shop' },
  { name: 'webinar', path: '/webinar' },
  { name: 'article', path: '/article' },
  { name: 'campaign_friend_adviser', path: '/campaign/friend_adviser' },
  { name: 'campaign_syanaisyoukai', path: '/campaign/syanaisyoukai' },
  { name: 'lp_seminar005', path: '/lp/seminar005' },
  { name: 'lp_alliance_interspace', path: '/lp/alliance_interspace' },
  { name: 'lp_chumon011', path: '/lp/chumon011' },
  { name: 'lp_chumon012', path: '/lp/chumon012' },
  { name: 'lp_linesoudan', path: '/lp/linesoudan' },
  { name: 'lp_linesoudan001', path: '/lp/linesoudan001' },
  { name: 'lp_linesoudan002', path: '/lp/linesoudan002' },
  { name: 'lp_market001', path: '/lp/market001' },
  { name: 'lp_online001', path: '/lp/online001' },
  { name: 'lp_seminar002', path: '/lp/seminar002' }
];

const environments = [
  { name: 'localhost', url: 'http://localhost:3000' },
  { name: 'production', url: 'https://counter.homes.co.jp' }
];

const viewports = [
  { name: 'PC', width: 1280, height: 1024 },
  { name: 'SP', width: 375, height: 812 }
];

function compareImages(img1Path, img2Path, diffPath) {
  const img1 = PNG.sync.read(fs.readFileSync(img1Path));
  const img2 = PNG.sync.read(fs.readFileSync(img2Path));
  const { width, height } = img1;

  if (img1.width !== img2.width || img1.height !== img2.height) {
    return { match: false, diffPixels: -1, error: 'Image dimensions do not match' };
  }

  const diff = new PNG({ width, height });
  const diffPixels = pixelmatch(img1.data, img2.data, diff.data, width, height, { threshold: 0.1 });

  if (diffPixels > 0) {
    fs.writeFileSync(diffPath, PNG.sync.write(diff));
  }

  return { match: diffPixels === 0, diffPixels, totalPixels: width * height };
}

(async () => {
  const browser = await chromium.launch();
  const results = [];
  
  console.log('📸 スクリーンショット取得中...\n');
  
  // スクリーンショット取得
  for (const env of environments) {
    console.log(`📍 ${env.name}...`);
    
    for (const page of pages) {
      for (const viewport of viewports) {
        try {
          const context = await browser.newContext({
            viewport: { width: viewport.width, height: viewport.height }
          });
          
          const browserPage = await context.newPage();
          await browserPage.goto(`${env.url}${page.path}`, { 
            waitUntil: 'networkidle',
            timeout: 30000 
          });
          
          await browserPage.waitForTimeout(2000);
          
          const filename = `${env.name}_${page.name}_${viewport.name}.png`;
          await browserPage.screenshot({ 
            path: filename, 
            fullPage: true 
          });
          
          console.log(`  ✓ ${filename}`);
          await context.close();
        } catch (error) {
          console.error(`  ✗ ${env.name}_${page.name}_${viewport.name}: ${error.message}`);
        }
      }
    }
  }
  
  await browser.close();
  
  console.log('\n🔍 画像比較中...\n');
  
  // 画像比較
  for (const page of pages) {
    for (const viewport of viewports) {
      const localImg = `localhost_${page.name}_${viewport.name}.png`;
      const prodImg = `production_${page.name}_${viewport.name}.png`;
      const diffImg = `diff_${page.name}_${viewport.name}.png`;
      
      if (fs.existsSync(localImg) && fs.existsSync(prodImg)) {
        const result = compareImages(localImg, prodImg, diffImg);
        
        if (result.error) {
          console.log(`  ⚠️  ${page.name} (${viewport.name}): ${result.error}`);
          results.push({ page: page.name, viewport: viewport.name, status: 'ERROR', error: result.error });
        } else if (result.match) {
          console.log(`  ✅ ${page.name} (${viewport.name}): 完全一致`);
          results.push({ page: page.name, viewport: viewport.name, status: 'PASS', diffPixels: 0 });
        } else {
          const diffPercent = ((result.diffPixels / result.totalPixels) * 100).toFixed(2);
          console.log(`  ❌ ${page.name} (${viewport.name}): ${result.diffPixels}ピクセル差異 (${diffPercent}%)`);
          results.push({ page: page.name, viewport: viewport.name, status: 'FAIL', diffPixels: result.diffPixels, diffPercent });
        }
      }
    }
  }
  
  // 結果サマリー
  const passed = results.filter(r => r.status === 'PASS').length;
  const failed = results.filter(r => r.status === 'FAIL').length;
  const errors = results.filter(r => r.status === 'ERROR').length;
  
  console.log('\n📊 結果サマリー');
  console.log(`  ✅ PASS: ${passed}`);
  console.log(`  ❌ FAIL: ${failed}`);
  console.log(`  ⚠️  ERROR: ${errors}`);
  
  // JSON出力
  fs.writeFileSync('comparison_results.json', JSON.stringify(results, null, 2));
  console.log('\n📁 comparison_results.json に結果を保存しました');
  
  if (failed > 0) {
    console.log('\n⚠️  差分画像は diff_*.png として保存されています');
  }
})();
