import { chromium } from 'playwright';
import { createWriteStream, existsSync, mkdirSync } from 'fs';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

const pages = [
  { name: 'article', path: '/article' },
  { name: 'campaign_friend_adviser', path: '/campaign/friend_adviser' },
  { name: 'campaign_syanaisyoukai', path: '/campaign/syanaisyoukai' },
  { name: 'lp_seminar005', path: '/lp/seminar005' },
  { name: 'lp_alliance_interspace', path: '/lp/alliance_interspace' },
  { name: 'lp_chumon011', path: '/lp/chumon011' },
  { name: 'lp_chumon012', path: '/lp/chumon012' },
  { name: 'lp_linesoudan', path: '/lp/linesoudan' },
  { name: 'lp_linesoudan001', path: '/lp/linesoudan001' },
  { name: 'lp_linesoudan002', path: '/lp/linesoudan002' },
  { name: 'lp_market001', path: '/lp/market001' },
  { name: 'lp_online001', path: '/lp/online001' },
  { name: 'lp_seminar002', path: '/lp/seminar002' },
  { name: 'chumon', path: '/chumon' },
  { name: 'ckodate', path: '/ckodate' },
  { name: 'cmansion', path: '/cmansion' },
  { name: 'reform_renovation', path: '/reform_renovation' },
  { name: 'online', path: '/online' },
  { name: 'reserve', path: '/reserve' },
  { name: 'top', path: '/' },
  { name: 'voices_online', path: '/voices-online' },
  { name: 'voices_shop', path: '/voices-shop' },
  { name: 'webinar', path: '/webinar' },
  { name: 'book', path: '/book' },
  { name: 'skodate', path: '/skodate' },
  { name: 'about', path: '/about' }
];

const viewports = [
  { name: 'PC', width: 1280, height: 1024 },
  { name: 'SP', width: 375, height: 812 }
];

async function captureScreenshots() {
  console.log('\n📸 ステップ1: ローカル環境のキャプチャ取得中...\n');
  
  const browser = await chromium.launch();
  let successCount = 0;
  let errorCount = 0;
  
  for (const page of pages) {
    for (const viewport of viewports) {
      const context = await browser.newContext({ viewport });
      const browserPage = await context.newPage();
      
      try {
        await browserPage.goto(`http://localhost:3000${page.path}`, { 
          waitUntil: 'domcontentloaded',
          timeout: 15000 
        });
        await browserPage.waitForTimeout(2000);
        
        const filename = `localhost_${page.name}_${viewport.name}.png`;
        await browserPage.screenshot({ 
          path: filename,
          fullPage: true 
        });
        console.log(`  ✓ ${filename}`);
        successCount++;
      } catch (error) {
        console.log(`  ✗ ${page.name}_${viewport.name}: ${error.message.split('\n')[0]}`);
        errorCount++;
      }
      
      await context.close();
    }
  }
  
  await browser.close();
  console.log(`\n✅ キャプチャ完了: 成功 ${successCount}, エラー ${errorCount}\n`);
  return { successCount, errorCount };
}

async function compressImages() {
  console.log('\n🗜️  ステップ2: 画像圧縮中...\n');
  
  const compressDir = 'compressed';
  if (!existsSync(compressDir)) {
    mkdirSync(compressDir);
  }
  
  let compressCount = 0;
  
  for (const page of pages) {
    for (const viewport of viewports) {
      const filename = `localhost_${page.name}_${viewport.name}.png`;
      const prodFilename = `production_${page.name}_${viewport.name}.png`;
      
      if (existsSync(filename)) {
        const maxSize = viewport.name === 'PC' ? 1280 : 800;
        const compressedFile = `${compressDir}/${filename}`;
        
        try {
          await execAsync(`sips -Z ${maxSize} ${filename} --out ${compressedFile} 2>/dev/null`);
          compressCount++;
        } catch (error) {
          console.log(`  ⚠️  ${filename}: 圧縮失敗`);
        }
      }
      
      if (existsSync(prodFilename)) {
        const maxSize = viewport.name === 'PC' ? 1280 : 800;
        const compressedFile = `${compressDir}/${prodFilename}`;
        
        try {
          await execAsync(`sips -Z ${maxSize} ${prodFilename} --out ${compressedFile} 2>/dev/null`);
          compressCount++;
        } catch (error) {
          console.log(`  ⚠️  ${prodFilename}: 圧縮失敗`);
        }
      }
    }
  }
  
  console.log(`\n✅ 圧縮完了: ${compressCount}ファイル\n`);
  return compressCount;
}

async function compareImages() {
  console.log('\n🔍 ステップ3: 画像比較実行中...\n');
  
  try {
    const { stdout } = await execAsync('node compare-existing.js');
    console.log(stdout);
    return true;
  } catch (error) {
    console.log(error.stdout || error.message);
    return false;
  }
}

async function openReport() {
  console.log('\n📊 ステップ4: 比較レポートを開きます...\n');
  
  try {
    await execAsync('open comparison_report.html');
    console.log('✅ comparison_report.html を開きました\n');
    return true;
  } catch (error) {
    console.log('⚠️  レポートを開けませんでした\n');
    return false;
  }
}

(async () => {
  console.log('🚀 CSS統合テスト - 完全再テスト開始\n');
  console.log('対象: 27ページ × 2画面 (PC/SP) = 54キャプチャ\n');
  
  try {
    // ステップ1: キャプチャ取得
    const captureResult = await captureScreenshots();
    
    if (captureResult.successCount === 0) {
      console.log('❌ キャプチャが1つも取得できませんでした');
      console.log('   ローカルサーバーが起動しているか確認してください');
      process.exit(1);
    }
    
    // ステップ2: 画像圧縮（ファイルサイズ対策）
    await compressImages();
    
    // ステップ3: 画像比較
    await compareImages();
    
    // ステップ4: レポート表示
    await openReport();
    
    console.log('✅ 全ステップ完了\n');
    console.log('📋 次のアクション:');
    console.log('   1. comparison_report.html で差異を確認');
    console.log('   2. 問題なければテスト完了');
    console.log('   3. 差異があれば修正して再実行\n');
    
  } catch (error) {
    console.error('❌ エラー:', error.message);
    process.exit(1);
  }
})();
