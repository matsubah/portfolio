# CSS統合テスト - 使い方

## 📋 概要

ローカル環境と本番環境の画面表示を比較し、CSS統合作業が正しく完了していることを確認するツール。

**対象:** 27ページ × PC/SP = 54画面

---

## 🚀 クイックスタート

### 1. 環境準備

```bash
# Playwrightインストール（初回のみ）
npm install -g playwright
npx playwright install chromium

# ディレクトリ移動
cd /Users/matsubah/Documents/CSS統合テスト結果
```

### 2. ローカルサーバー起動

```bash
cd /Users/matsubah/projects/madoguchi-web
bin/rails server
```

### 3. テスト実行

#### 方法A: 完全自動テスト（推奨）
```bash
cd /Users/matsubah/Documents/CSS統合テスト結果
node full-retest.js
```

自動で以下を実行：
1. ローカル環境のキャプチャ取得
2. 画像圧縮（オプション）
3. 画像比較
4. レポート表示

#### 方法B: 手動実行
```bash
# ステップ1: キャプチャ取得
node screenshot-test.js

# ステップ2: 画像比較
node compare-existing.js

# ステップ3: レポート確認
open comparison_report.html
```

---

## 📁 ファイル構成

```
CSS統合テスト結果/
├── screenshot-test.js          # 全ページキャプチャ取得
├── compare-existing.js         # 画像比較実行
├── full-retest.js              # 完全自動テスト
├── screenshot-compare.js       # 比較ロジック（内部使用）
├── package.json                # 依存関係
├── comparison_report.html      # 比較レポート（自動生成）
├── README.md                   # このファイル
├── CSS統合テスト_GitHub_Issue.md  # テスト計画・チェックリスト
├── 最終比較結果_20251222.md    # 最終結果レポート
├── 修正記録_20251222.md        # 修正内容の記録
└── [画像ファイル群]
    ├── localhost_*.png         # ローカル環境キャプチャ
    ├── production_*.png        # 本番環境キャプチャ
    └── *_diff_*.png            # 差分画像（自動生成）
```

---

## 🔧 各スクリプトの詳細

### screenshot-test.js
**用途:** 全27ページのキャプチャ取得（本番・ローカル両方）

**実行:**
```bash
node screenshot-test.js
```

**出力:**
- `localhost_[ページ名]_PC.png`
- `localhost_[ページ名]_SP.png`
- `production_[ページ名]_PC.png`
- `production_[ページ名]_SP.png`

**注意:**
- タイムアウトが発生する場合は個別に再取得
- 本番環境のキャプチャは既に取得済みの場合はスキップ可能

---

### compare-existing.js
**用途:** 取得済みキャプチャの比較

**実行:**
```bash
node compare-existing.js
```

**出力:**
- `comparison_report.html` - 視覚的な比較レポート
- `*_diff_*.png` - 差分画像（赤色でハイライト）
- コンソールに結果サマリー表示

**判定基準:**
- ✅ PASS: 完全一致
- ❌ FAIL: 差異あり（差異率%表示）
- ⚠️ ERROR: サイズ不一致（動的コンテンツの影響）

---

### full-retest.js
**用途:** 全工程を自動実行

**実行:**
```bash
node full-retest.js
```

**処理フロー:**
1. ローカル環境のキャプチャ取得（27ページ × PC/SP）
2. 画像圧縮（ファイルサイズ削減）
3. 画像比較実行
4. comparison_report.html を自動で開く

**注意:**
- ローカルサーバーが起動している必要あり
- 実行時間: 約5-10分

---

## 🎯 個別ページの再取得

特定のページだけ再取得したい場合：

### 方法1: screenshot-test.jsを編集

```javascript
// screenshot-test.js の pages 配列を編集
const pages = [
  { name: 'chumon', path: '/chumon' },
  { name: 'reserve', path: '/reserve' }
  // 必要なページだけ残す
];
```

### 方法2: 簡易スクリプト作成

```javascript
// quick-capture.js として保存
import { chromium } from 'playwright';

const pages = [
  { name: 'ページ名', path: '/パス' }
];

const viewports = [
  { name: 'PC', width: 1280, height: 1024 },
  { name: 'SP', width: 375, height: 812 }
];

(async () => {
  const browser = await chromium.launch();
  
  for (const page of pages) {
    for (const vp of viewports) {
      const context = await browser.newContext({ viewport: vp });
      const browserPage = await context.newPage();
      
      await browserPage.goto(`http://localhost:3000${page.path}`, { 
        waitUntil: 'load',
        timeout: 45000 
      });
      
      await browserPage.waitForTimeout(5000);
      await browserPage.evaluate(() => document.fonts.ready);
      await browserPage.waitForTimeout(2000);
      
      await browserPage.screenshot({ 
        path: `localhost_${page.name}_${vp.name}.png`,
        fullPage: true 
      });
      
      console.log(`✓ localhost_${page.name}_${vp.name}.png`);
      await context.close();
    }
  }
  
  await browser.close();
})();
```

実行:
```bash
node quick-capture.js
```

---

## 📊 結果の見方

### comparison_report.html

ブラウザで開くと以下が表示されます：

1. **ページ一覧** - 全ページのサムネイル
2. **差分画像** - 赤色でハイライトされた差異
3. **差異率** - パーセンテージで表示

**判定基準:**
- **< 0.5%**: 許容範囲（レンダリング差異、微小な変更）
- **0.5-1.0%**: 要確認（動的コンテンツの可能性）
- **> 1.0%**: 要確認（大きな差異）

### コンソール出力

```
📊 結果サマリー
  ✅ PASS: 0
  ❌ FAIL: 20
  ⚠️  ERROR: 30
  📁 総ページ数: 25 (PC/SP各25画面)

差異があったページ:
  - market_chumon (SP): 0.28%
  - campaign_syanaisy (PC): 0.13%
  ...
```

---

## 🔍 トラブルシューティング

### タイムアウトが発生する

**原因:** ページの読み込みが遅い、動的コンテンツが多い

**対処:**
1. 待機時間を延長
2. 待機戦略を変更（`networkidle` → `load`）
3. 個別に再取得

```javascript
// 待機時間延長
await page.goto(url, { 
  waitUntil: 'load',
  timeout: 60000  // 60秒に延長
});

await page.waitForTimeout(7000);  // 7秒待機
```

### アイコンが表示されない

**原因:** フォント読み込みが完了していない

**対処:**
```javascript
// フォント読み込み待機を追加
await page.evaluate(() => document.fonts.ready);
await page.waitForTimeout(2000);
```

### サイズ不一致エラー

**原因:** 動的コンテンツ（広告等）でページ高さが異なる

**対処:**
- 目視確認が必要
- comparison_report.htmlで差分画像を確認
- 問題なければ許容範囲として扱う

---

## 📝 チェックリスト

テスト実施時のチェックリスト：

### 事前準備
- [ ] Playwrightインストール済み
- [ ] ローカルサーバー起動済み
- [ ] 本番環境のキャプチャ取得済み（初回のみ）

### テスト実行
- [ ] 全ページのキャプチャ取得完了
- [ ] 画像比較実行完了
- [ ] comparison_report.html生成完了

### 結果確認
- [ ] 修正対象ページの差異確認
- [ ] 差異 > 0.5%のページを目視確認
- [ ] サイズ不一致ページを目視確認
- [ ] レイアウト崩れがないことを確認
- [ ] アイコン・画像が正しく表示されていることを確認

### 完了条件
- [ ] 全ページで問題なし、または許容範囲内
- [ ] 最終レポート作成完了
- [ ] 修正記録作成完了

---

## 📚 関連ドキュメント

- **CSS統合テスト_GitHub_Issue.md** - 詳細なテスト計画とチェックリスト
- **最終比較結果_20251222.md** - 最終結果レポート
- **修正記録_20251222.md** - 修正内容の記録
- **ファイル整理ガイド.md** - ファイル構成の説明

---

## 🆘 サポート

問題が発生した場合：

1. `comparison_report.html`で差分画像を確認
2. コンソール出力のエラーメッセージを確認
3. 個別ページを再取得して再比較
4. それでも解決しない場合は目視確認

---

**最終更新:** 2025-12-22 21:22
