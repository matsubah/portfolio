import { chromium } from 'playwright';

const pages = [
  { name: 'article', path: '/article' },
  { name: 'campaign_friend_adviser', path: '/campaign/friend_adviser' },
  { name: 'campaign_syanaisyoukai', path: '/campaign/syanaisyoukai' },
  { name: 'lp_seminar005', path: '/lp/seminar005' },
  { name: 'lp_alliance_interspace', path: '/lp/alliance_interspace' },
  { name: 'lp_chumon011', path: '/lp/chumon011' },
  { name: 'lp_chumon012', path: '/lp/chumon012' },
  { name: 'lp_linesoudan', path: '/lp/linesoudan' },
  { name: 'lp_linesoudan001', path: '/lp/linesoudan001' },
  { name: 'lp_linesoudan002', path: '/lp/linesoudan002' },
  { name: 'lp_market001', path: '/lp/market001' },
  { name: 'lp_online001', path: '/lp/online001' },
  { name: 'lp_seminar002', path: '/lp/seminar002' },
  { name: 'chumon', path: '/chumon' },
  { name: 'ckodate', path: '/ckodate' },
  { name: 'cmansion', path: '/cmansion' },
  { name: 'reform_renovation', path: '/reform_renovation' },
  { name: 'online', path: '/online' },
  { name: 'reserve', path: '/reserve' },
  { name: 'thanks', path: '/thanks' },
  { name: 'top', path: '/' },
  { name: 'voices_online', path: '/voices-online' },
  { name: 'voices_shop', path: '/voices-shop' },
  { name: 'webinar', path: '/webinar' },
  { name: 'book', path: '/book' },
  { name: 'skodate', path: '/skodate' },
  { name: 'about', path: '/about' }
];

const environments = [
  { name: 'localhost', url: 'http://localhost:3000' },
  { name: 'production', url: 'https://counter.homes.co.jp' }
];

const viewports = [
  { name: 'PC', width: 1280, height: 1024 },
  { name: 'SP', width: 375, height: 812 }
];

(async () => {
  const browser = await chromium.launch();
  let successCount = 0;
  let errorCount = 0;
  
  for (const env of environments) {
    console.log(`\n📍 Testing ${env.name}...`);
    
    for (const page of pages) {
      for (const viewport of viewports) {
        try {
          const context = await browser.newContext({
            viewport: { width: viewport.width, height: viewport.height }
          });
          
          const browserPage = await context.newPage();
          await browserPage.goto(`${env.url}${page.path}`, { 
            waitUntil: 'networkidle',
            timeout: 30000 
          });
          
          // 追加の待機（画像読み込み等）
          await browserPage.waitForTimeout(2000);
          
          const filename = `${env.name}_${page.name}_${viewport.name}.png`;
          await browserPage.screenshot({ 
            path: filename, 
            fullPage: true 
          });
          
          console.log(`  ✓ ${filename}`);
          successCount++;
          
          await context.close();
        } catch (error) {
          console.error(`  ✗ ${env.name}_${page.name}_${viewport.name}: ${error.message}`);
          errorCount++;
        }
      }
    }
  }
  
  await browser.close();
  
  console.log(`\n📊 Results: ${successCount} success, ${errorCount} errors`);
  console.log(`📁 Screenshots saved to: ${process.cwd()}`);
})();
