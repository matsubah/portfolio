import fs from 'fs';
import { PNG } from 'pngjs';
import pixelmatch from 'pixelmatch';
import path from 'path';

const CAPTURE_DIR = '/Users/matsubah/Downloads/css_test_captures';

const pages = [
  'market_chumon', 'market_ckodate', 'market_cmansion', 'market_reform',
  'voice_shop', 'voice_online',
  'article', 'online', 'webinar',
  'reserve',
  'campaign_syanaisy', 'campaign_friend',
  'top',
  'lp_seminar002', 'lp_chumon011', 'lp_chumon012', 'lp_online001',
  'lp_alliance', 'lp_linesoudan', 'lp_linesoudan001', 'lp_linesoudan002',
  'lp_market001',
  'about', 'skodate', 'books'
];

function compareImages(img1Path, img2Path, diffPath) {
  try {
    const img1 = PNG.sync.read(fs.readFileSync(img1Path));
    const img2 = PNG.sync.read(fs.readFileSync(img2Path));
    
    if (img1.width !== img2.width || img1.height !== img2.height) {
      return { match: false, diffPixels: -1, error: 'サイズ不一致' };
    }

    const { width, height } = img1;
    const diff = new PNG({ width, height });
    const diffPixels = pixelmatch(img1.data, img2.data, diff.data, width, height, { threshold: 0.1 });

    if (diffPixels > 0) {
      fs.writeFileSync(diffPath, PNG.sync.write(diff));
    }

    return { match: diffPixels === 0, diffPixels, totalPixels: width * height };
  } catch (error) {
    return { match: false, diffPixels: -1, error: error.message };
  }
}

console.log('🔍 CSS統合テスト - 画像比較開始\n');

const results = [];
let passCount = 0;
let failCount = 0;
let errorCount = 0;

for (const page of pages) {
  console.log(`[${page}]`);
  
  for (const device of ['pc', 'sp']) {
    const localImg = path.join(CAPTURE_DIR, `${page}_local_${device}.png`);
    const prodImg = path.join(CAPTURE_DIR, `${page}_prod_${device}.png`);
    const diffImg = path.join(CAPTURE_DIR, `${page}_diff_${device}.png`);
    
    if (!fs.existsSync(localImg) || !fs.existsSync(prodImg)) {
      console.log(`  ⚠️  ${device.toUpperCase()}: 画像ファイルが見つかりません`);
      errorCount++;
      results.push({ page, device: device.toUpperCase(), status: 'ERROR', error: 'ファイル未検出' });
      continue;
    }
    
    const result = compareImages(localImg, prodImg, diffImg);
    
    if (result.error) {
      console.log(`  ⚠️  ${device.toUpperCase()}: ${result.error}`);
      errorCount++;
      results.push({ page, device: device.toUpperCase(), status: 'ERROR', error: result.error });
    } else if (result.match) {
      console.log(`  ✅ ${device.toUpperCase()}: 完全一致`);
      passCount++;
      results.push({ page, device: device.toUpperCase(), status: 'PASS', diffPixels: 0 });
    } else {
      const diffPercent = ((result.diffPixels / result.totalPixels) * 100).toFixed(2);
      console.log(`  ❌ ${device.toUpperCase()}: ${result.diffPixels}px差異 (${diffPercent}%)`);
      failCount++;
      results.push({ page, device: device.toUpperCase(), status: 'FAIL', diffPixels: result.diffPixels, diffPercent });
    }
  }
  console.log('');
}

console.log('📊 結果サマリー');
console.log(`  ✅ PASS: ${passCount}`);
console.log(`  ❌ FAIL: ${failCount}`);
console.log(`  ⚠️  ERROR: ${errorCount}`);
console.log(`  📁 総ページ数: ${pages.length} (PC/SP各${pages.length}画面)`);

// JSON出力
const outputPath = path.join(CAPTURE_DIR, 'comparison_results.json');
fs.writeFileSync(outputPath, JSON.stringify(results, null, 2));
console.log(`\n📄 ${outputPath} に結果を保存しました`);

if (failCount > 0) {
  console.log('\n⚠️  差分画像は *_diff_*.png として保存されています');
  console.log('\n差異があったページ:');
  results.filter(r => r.status === 'FAIL').forEach(r => {
    console.log(`  - ${r.page} (${r.device}): ${r.diffPercent}%`);
  });
}

process.exit(failCount > 0 ? 1 : 0);
